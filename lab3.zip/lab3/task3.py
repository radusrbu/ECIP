import numpy as np

# Generate X ~ Uniform(0,1)
X = np.random.uniform(0, 1, 1000)

# Sample mean
sample_mean = np.mean(X)

print("Sample mean =", sample_mean)

'''
Sample mean → computed from generated data
Theoretical mean → 0.5

Because we only generate 1000 values, the sample mean will not be exactly 0.5, but it should be close.

Example output:

Sample mean = 0.497

Small differences appear due to randomness.

Interpretation of expectation

The expectation (mean value) of a random variable represents the average value that we obtain if the experiment is repeated many times.

For the Uniform(0,1) distribution, the expected value is 0.5, meaning that the values are centered in the middle of the interval.

The sample mean calculated from simulated data is an estimate of the theoretical expectation.
When the number of samples increases, the sample mean becomes closer to the theoretical mean.

This illustrates the law of large numbers, which states that the average of many random samples converges to the expected value.

Therefore, the result confirms that the simulated data follows the Uniform(0,1) distribution and that the expectation represents the long-term average of the random variable.
'''