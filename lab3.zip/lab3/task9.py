import numpy as np
import matplotlib.pyplot as plt

# Generate first random variable
x = np.random.normal(0, 1, 1000)

# Generate correlated variable
noise = np.random.normal(0, 0.5, 1000)
y = 2 * x + noise

# Compute covariance
cov_matrix = np.cov(x, y)
cov_xy = cov_matrix[0, 1]

print("Covariance =", cov_xy)

# Scatter plot to see correlation
plt.figure()
plt.scatter(x, y, s=5)
plt.title("Correlated variables")
plt.xlabel("x")
plt.ylabel("y")
plt.show()