import numpy as np
import matplotlib.pyplot as plt

# Gaussian noise with small variance (std = 1)
noise1 = np.random.normal(0, 1, 1000)

# Gaussian noise with larger variance (std = 2)
noise2 = np.random.normal(0, 2, 1000)

# Plot first distribution
plt.figure()
plt.hist(noise1, bins=20)
plt.title("Gaussian noise, std = 1")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.show()

# Plot second distribution
plt.figure()
plt.hist(noise2, bins=20)
plt.title("Gaussian noise, std = 2")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.show()

