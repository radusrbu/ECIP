import numpy as np
import matplotlib.pyplot as plt

# Step 1: generate 1000 random numbers
numbers = np.random.rand(1000)

# Step 2: plot histogram
plt.figure()
plt.hist(numbers, bins=20)

plt.title("Histogram of 1000 Random Numbers")
plt.xlabel("Value")
plt.ylabel("Frequency")

plt.show()

''' The generated numbers appear random because they do not follow a visible pattern and each value is independent of the others.
NumPy uses a pseudo-random number generator, which produces numbers that behave like random values from a statistical point of view.

In a uniform distribution, all intervals should contain approximately the same number of values.
In the histogram, the bars are not exactly equal, but they are similar in height, which indicates that the numbers are randomly distributed.

Small differences between bins are normal and expected due to randomness.
If we generate more numbers (for example 10,000 or 100,000), the histogram will become more uniform and closer to the theoretical distribution.

This shows that the generated sequence has good randomness properties.
'''