import numpy as np

X1 = np.random.uniform(0, 1, 1000)

X2 = np.random.uniform(0, 2, 1000)

# Variance
var1 = np.var(X1)
var2 = np.var(X2)


mean1 = np.mean(X1)
mean2 = np.mean(X2)

print("Dataset 1 mean =", mean1)
print("Dataset 1 variance =", var1)

print("Dataset 2 mean =", mean2)
print("Dataset 2 variance =", var2)

'''
Analyze spread around mean

Variance measures how far the values are spread around the mean.

Small variance → values close to mean
Large variance → values more spread out

For Uniform(0,1), values are between 0 and 1, so the spread is small.
For Uniform(0,2), values are between 0 and 2, so the spread is larger.

Because of this, the variance of the second dataset is bigger.

Comparison of datasets with different variance

Dataset 1 (Uniform 0–1):

smaller interval
smaller variance
values closer to mean

Dataset 2 (Uniform 0–2):

larger interval
larger variance
values more spread out

Even if both distributions are uniform, the one with the larger interval has a larger variance.

This shows that variance depends on how wide the distribution is, not only on the mean.


'''