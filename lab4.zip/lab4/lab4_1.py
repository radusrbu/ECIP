import numpy as np

x = np.array([1, 2, 3])
y = np.array([40, 42, 45])

A = np.column_stack((x, np.ones(len(x))))

params = np.linalg.lstsq(A, y, rcond=None)[0]
a, b = params

print("Matrix A:")
print(A)
print("\nVector y:")
print(y)
print("\na =", a)
print("b =", b)