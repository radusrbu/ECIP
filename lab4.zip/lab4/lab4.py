import numpy as np

y = np.array([21, 22, 23, 24])

x = np.mean(y)

print("Calibrated temperature:", x)
