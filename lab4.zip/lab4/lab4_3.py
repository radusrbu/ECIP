import numpy as np

sensor1 = np.array([1, 2])
sensor2 = np.array([2, 4])

A = np.column_stack((sensor1, sensor2))

print("Matrix A:")
print(A)

detA = np.linalg.det(A)
rankA = np.linalg.matrix_rank(A)

print("Determinant:", detA)
print("Rank:", rankA)