import numpy as np

e = np.array([-1, 2, -2])

squared_errors = e**2
SSE = np.sum(squared_errors)

absolute_errors = np.abs(e)
SAE = np.sum(absolute_errors)

print("Errors:", e)
print("Squared errors:", squared_errors)
print("Total Squared Error (SSE):", SSE)

print("\nAbsolute errors:", absolute_errors)
print("Total Absolute Error (SAE):", SAE)