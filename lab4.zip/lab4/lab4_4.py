import numpy as np
import matplotlib.pyplot as plt

time = np.array([1, 2, 3, 4])
energy = np.array([10, 14, 15, 20])

A = np.column_stack((time, np.ones(len(time))))

a, b = np.linalg.lstsq(A, energy, rcond=None)[0]

energy_pred = a * time + b

plt.scatter(time, energy, label="Data")
plt.plot(time, energy_pred, label="Fitted line")
plt.xlabel("Time")
plt.ylabel("Energy")
plt.legend()
plt.title("Energy vs Time")
plt.show()

print("Consumption rate (slope a):", a)
print("Intercept b:", b)